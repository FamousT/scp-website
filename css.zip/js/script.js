/* ============================================================
   SimmonsCooper Partners — script.js
   ============================================================ */
(function () {
  "use strict";

  const header = document.getElementById("siteHeader");
  const nav = document.getElementById("primaryNav");
  const toggle = document.getElementById("menuToggle");
  const navLinks = Array.from(document.querySelectorAll(".nav-link"));

  /* ---------- Sticky header state ---------- */
  const onScroll = () => {
    if (window.scrollY > 40) header.classList.add("scrolled");
    else header.classList.remove("scrolled");
  };
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  /* ---------- Mobile menu ---------- */
  const closeMenu = () => {
    nav.classList.remove("open");
    toggle.classList.remove("open");
    toggle.setAttribute("aria-expanded", "false");
  };
  toggle.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    toggle.classList.toggle("open", open);
    toggle.setAttribute("aria-expanded", String(open));
  });
  navLinks.forEach((l) => l.addEventListener("click", closeMenu));
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeMenu();
  });

  /* ---------- Smooth scroll (with header offset) ---------- */
  document.querySelectorAll('a[href^="#"]').forEach((a) => {
    a.addEventListener("click", (e) => {
      const id = a.getAttribute("href");
      if (id.length <= 1) return;
      const target = document.querySelector(id);
      if (!target) return;
      e.preventDefault();
      const y = target.getBoundingClientRect().top + window.scrollY - 70;
      window.scrollTo({ top: y, behavior: "smooth" });
    });
  });

  /* ---------- Scroll reveal ---------- */
  const reveals = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window) {
    const io = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("in");
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15, rootMargin: "0px 0px -8% 0px" }
    );
    reveals.forEach((el) => io.observe(el));
  } else {
    reveals.forEach((el) => el.classList.add("in"));
  }

  /* ---------- Count-up stats ---------- */
  const stats = document.querySelectorAll(".stat-num");
  const runCount = (el) => {
    const target = parseInt(el.dataset.target, 10) || 0;
    const suffix = el.dataset.suffix || "";
    const duration = 1600;
    const start = performance.now();
    const step = (now) => {
      const p = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(target * eased) + (p === 1 ? suffix : "");
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  };
  if ("IntersectionObserver" in window && stats.length) {
    const so = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            runCount(entry.target);
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.6 }
    );
    stats.forEach((el) => so.observe(el));
  } else {
    stats.forEach((el) => (el.textContent = (el.dataset.target || "") + (el.dataset.suffix || "")));
  }

  /* ---------- Active nav highlight ---------- */
  const sections = navLinks
    .map((l) => document.querySelector(l.getAttribute("href")))
    .filter(Boolean);
  if ("IntersectionObserver" in window && sections.length) {
    const spy = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const id = "#" + entry.target.id;
            navLinks.forEach((l) =>
              l.classList.toggle("active", l.getAttribute("href") === id)
            );
          }
        });
      },
      { threshold: 0.5, rootMargin: "-20% 0px -60% 0px" }
    );
    sections.forEach((s) => spy.observe(s));
  }

  /* ---------- Hero background slideshow ---------- */
  (function heroSlideshow() {
    const slides = Array.from(document.querySelectorAll(".hero-slide"));
    if (slides.length < 2) return;

    const bars = Array.from(document.querySelectorAll(".hero-bar"));
    const caption = document.querySelector(".hero-caption");
    const controls = document.getElementById("heroControls");

    /* read the hold time from CSS so markup, styles and JS stay in sync */
    const cssMs = getComputedStyle(document.documentElement)
      .getPropertyValue("--hero-slide-ms")
      .trim();
    const parsed = parseFloat(cssMs);
    const HOLD = parsed ? (cssMs.endsWith("ms") ? parsed : parsed * 1000) : 6000;

    let index = slides.findIndex((s) => s.classList.contains("is-active"));
    if (index < 0) index = 0;
    let timer = null;

    const restartAnim = (el) => {
      if (!el) return;
      el.style.animation = "none";
      void el.offsetWidth; /* force reflow so the animation replays */
      el.style.animation = "";
    };

    const show = (n) => {
      index = (n + slides.length) % slides.length;

      slides.forEach((slide, i) => {
        const on = i === index;
        slide.classList.toggle("is-active", on);
        if (on) restartAnim(slide.querySelector("img"));
      });

      bars.forEach((bar, i) => {
        bar.classList.remove("is-active");
        if (i === index) {
          restartAnim(bar.querySelector(".hero-bar-fill"));
          bar.classList.add("is-active");
        }
      });

      if (caption) {
        const text = slides[index].getAttribute("data-caption");
        if (text) caption.textContent = text;
      }
    };

    const stop = () => {
      if (timer) clearInterval(timer);
      timer = null;
    };
    const start = () => {
      stop();
      timer = setInterval(() => show(index + 1), HOLD);
    };
    const goTo = (n) => {
      show(n);
      start();
    };

    if (controls) {
      controls.addEventListener("click", (e) => {
        const btn = e.target.closest("button");
        if (!btn) return;
        const dir = btn.getAttribute("data-hero");
        const jump = btn.getAttribute("data-hero-go");
        if (dir === "next") goTo(index + 1);
        else if (dir === "prev") goTo(index - 1);
        else if (jump !== null) goTo(parseInt(jump, 10));
      });
    }

    /* don't advance while the tab is in the background */
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) stop();
      else goTo(index + 1);
    });

    show(index);
    start();
  })();

  /* ---------- Update footer year ---------- */
  document.querySelectorAll("[data-year]").forEach((el) => {
    el.textContent = new Date().getFullYear();
  });
})();
