# -*- coding: utf-8 -*-
"""Contact page: enquiry form beside General Enquiries + sitewide WhatsApp button."""
import io, os, re, sys

ROOT = sys.argv[1]
os.chdir(ROOT)

WA_NUMBER = "2347011404511"
WA_TEXT = "Hello%20SimmonsCooper%20Partners%2C%20I%20would%20like%20to%20make%20an%20enquiry."
WA_PATH = ("M16.004 0h-.008C7.174 0 .01 7.166.01 16c0 3.506 1.13 6.75 3.05 9.383L1.06 31.4l6.222-1.99"
           "A15.9 15.9 0 0 0 16.004 32C24.83 32 32 24.834 32 16S24.83 0 16.004 0zm9.31 22.594c-.386 1.09-1.92 "
           "1.995-3.143 2.26-.836.178-1.93.32-5.61-1.205-4.71-1.95-7.74-6.73-7.976-7.04-.226-.31-1.9-2.53-1.9-4.826"
           "s1.166-3.425 1.636-3.905c.386-.394.98-.574 1.55-.574.184 0 .35.01.5.017.47.02.706.048 1.016.79.386.93 "
           "1.326 3.226 1.438 3.46.114.235.228.553.07.863-.148.32-.278.46-.512.73-.234.27-.456.477-.69.767-.214.252"
           "-.456.522-.186.986.27.454 1.2 1.976 2.568 3.194 1.766 1.572 3.198 2.074 3.71 2.287.38.158.834.12 "
           "1.112-.176.354-.38.79-1.012 1.234-1.634.316-.446.714-.5 1.132-.344.426.148 2.712 1.278 3.176 1.508.464"
           ".232.77.344.884.54.112.196.112 1.12-.274 2.21z")

WA_HTML = """
  <!-- ============ FLOATING WHATSAPP ============ -->
  <a class="wa-float" href="https://wa.me/%s?text=%s" target="_blank" rel="noopener"
     aria-label="Chat with us on WhatsApp" data-track="cta:whatsapp:float" data-wa-float>
    <span class="wa-float-icon" aria-hidden="true"><svg viewBox="0 0 32 32" width="24" height="24" fill="currentColor" focusable="false"><path d="%s"/></svg></span>
    <span class="wa-float-label">Chat with us</span>
  </a>
""" % (WA_NUMBER, WA_TEXT, WA_PATH)

# ---------------------------------------------------------------------------
# 1. contact.html — rebuild the General Enquiries band as a two-column split
# ---------------------------------------------------------------------------
ENQUIRY_BAND = """  <!-- ============ ENQUIRY BAND ============
       Left: routing explainer. Right: the enquiry form, which posts to
       FormSubmit and is delivered by email to scprecords@scp-law.com.
       The Microsoft Forms link is kept as a secondary route.
  -->
  <section class="section enquiry-band" id="enquire">
    <div class="container enquiry-split">
      <div class="enquiry-copy">
        <p class="eyebrow enquiry-band-eyebrow reveal"><span class="rule"></span>General Enquiries</p>
        <h2 class="enquiry-band-title reveal">One enquiry, routed to <em>the right team.</em></h2>
        <p class="enquiry-band-lede reveal">Tell us the topic once and your enquiry reaches that practice directly &#8212; Competition to the competition team, Energy to the energy team, and so on. Careers go to HR; press goes to Marketing.</p>
        <ul class="enquiry-facts enquiry-facts--split reveal">
          <li><span class="enquiry-fact-k">Acknowledgement</span><span class="enquiry-fact-v">Immediate, by email</span></li>
          <li><span class="enquiry-fact-k">Substantive reply</span><span class="enquiry-fact-v">From a lawyer within 24 hours</span></li>
          <li><span class="enquiry-fact-k">Routing</span><span class="enquiry-fact-v">Ten practice teams, plus HR and Marketing</span></li>
          <li><span class="enquiry-fact-k">Your data</span><span class="enquiry-fact-v">Held under the Nigeria Data Protection Act</span></li>
        </ul>
        <p class="enquiry-band-foot reveal">We never publish partners' email addresses. For a general question, each office below has a direct line and WhatsApp. You can also <a href="https://forms.cloud.microsoft/Pages/ResponsePage.aspx?id=emEZHjkf7EqeDd6JuRMfnZ5g24hVddtNlcfkCrapooRUQlA4Q0dPUVJOTUJZR1VQWUc3R0dMNUlPVC4u" data-enquiry-link target="_blank" rel="noopener" data-track="cta:enquiry:contact">open our secure Microsoft form</a> in a new tab.</p>
      </div>

      <div class="enquiry-form-col reveal">
        <form class="form form-card enquiry-form" id="enquiryForm" data-enquiry-form
              action="https://formsubmit.co/scprecords@scp-law.com" method="POST" novalidate>
          <p class="card-cat">Send an enquiry</p>
          <h3 class="enquiry-form-title">Write to us directly.</h3>

          <!-- FormSubmit configuration -->
          <input type="hidden" name="_subject" value="Website enquiry &#8212; SimmonsCooper Partners" />
          <input type="hidden" name="_template" value="table" />
          <input type="hidden" name="_captcha" value="false" />
          <input type="text" name="_honey" class="hp-field" tabindex="-1" autocomplete="off" aria-hidden="true" />

          <div class="form-grid">
            <div class="field field--full">
              <label class="field-label" for="enqName">Full name <span class="req">*</span></label>
              <input class="input" id="enqName" name="name" type="text" required autocomplete="name" />
            </div>
            <div class="field">
              <label class="field-label" for="enqPhone">Phone <span class="req">*</span></label>
              <input class="input" id="enqPhone" name="phone" type="tel" required autocomplete="tel" inputmode="tel" />
            </div>
            <div class="field">
              <label class="field-label" for="enqEmail">Email <span class="req">*</span></label>
              <input class="input" id="enqEmail" name="email" type="email" required autocomplete="email" />
            </div>
            <div class="field field--full">
              <label class="field-label" for="enqOrg">Organisation <span class="field-opt">(optional)</span></label>
              <input class="input" id="enqOrg" name="organisation" type="text" autocomplete="organization" />
            </div>
            <div class="field field--full">
              <label class="field-label" for="enqMessage">Enquiry <span class="req">*</span></label>
              <textarea class="textarea" id="enqMessage" name="enquiry" required
                        placeholder="Tell us briefly what you are working on and which practice it concerns."></textarea>
            </div>
          </div>

          <p class="form-status" role="status" aria-live="polite" data-form-status></p>

          <div class="form-actions">
            <button class="btn btn--primary" type="submit" data-track="form:submit:enquiry">Send enquiry</button>
            <a class="btn btn--whatsapp btn--sm-wa" href="https://wa.me/%s?text=%s" target="_blank" rel="noopener" data-track="cta:whatsapp:enquiry">Chat with us</a>
          </div>
          <p class="form-note">Your details are used only to answer this enquiry and are held under the Nigeria Data Protection Act. Please do not send confidential or privileged material through this form &#8212; no lawyer&#8211;client relationship is created by submitting it.</p>
        </form>
      </div>
    </div>
  </section>
""" % (WA_NUMBER, WA_TEXT)

s = io.open("contact.html", encoding="utf-8").read()
start = s.index("  <!-- ============ ENQUIRY BAND ============")
end = s.index("  <section class=\"section section--white\" id=\"offices\">")
s = s[:start] + ENQUIRY_BAND + "\n" + s[end:]
io.open("contact.html", "w", encoding="utf-8").write(s)
print("contact.html — enquiry band rebuilt")

# ---------------------------------------------------------------------------
# 2. css/styles.css — split layout, form trimmings, floating WhatsApp
# ---------------------------------------------------------------------------
CSS = """

/* ============================================================
   CONTACT — ENQUIRY SPLIT + FLOATING WHATSAPP   (added 2026-08-26)
   ============================================================ */
.enquiry-split {
  position: relative;
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
  gap: clamp(2rem, 4.5vw, 4rem);
  align-items: start;
}
.enquiry-split .enquiry-band-eyebrow { justify-content: flex-start; margin-bottom: 1.4rem; }
.enquiry-split .enquiry-band-title { margin-inline: 0; max-width: 16ch; }
.enquiry-split .enquiry-band-lede { margin-inline: 0; max-width: 46ch; }
.enquiry-split .enquiry-band-foot { margin-inline: 0; max-width: 46ch; }
.enquiry-facts--split { grid-template-columns: repeat(2, minmax(0, 1fr)); margin-top: clamp(2rem, 3.5vw, 2.6rem); }
.enquiry-facts--split li:nth-child(odd) { border-left: 0; padding-left: 0; }
.enquiry-facts--split li:nth-child(n + 3) { border-top: 1px solid var(--line); }

.enquiry-form-col { position: relative; }
.enquiry-band .form-card { background: var(--white); box-shadow: 0 30px 60px -38px rgba(20, 33, 63, 0.5); }
.enquiry-form { gap: 1.15rem; }
.enquiry-form-title {
  font-family: var(--serif);
  font-weight: 400;
  font-size: clamp(1.35rem, 2.2vw, 1.7rem);
  line-height: 1.25;
  color: var(--ink);
  margin-top: 0.45rem;
  padding-bottom: 1.15rem;
  border-bottom: 1px solid var(--line);
}
.field-opt { font-weight: 400; letter-spacing: 0.08em; text-transform: none; color: var(--muted); }
.hp-field { position: absolute; left: -9999px; width: 1px; height: 1px; opacity: 0; pointer-events: none; }
.input.is-invalid, .textarea.is-invalid { border-color: #b4453c; box-shadow: 0 0 0 3px rgba(180, 69, 60, 0.12); }
.field-error { font-size: 0.74rem; color: #b4453c; line-height: 1.5; }
.form-status.is-error { border-left-color: #b4453c; background: rgba(180, 69, 60, 0.07); }
.form-status.is-ok { border-left-color: #1FA855; background: rgba(31, 168, 85, 0.08); }
.enquiry-form .form-actions { justify-content: flex-start; }
.btn--sm-wa { padding: 1rem 1.5rem; }
.btn[disabled] { opacity: 0.55; pointer-events: none; }

@media (max-width: 980px) {
  .enquiry-split { grid-template-columns: 1fr; }
  .enquiry-split .enquiry-band-title { max-width: 22ch; }
}
@media (max-width: 560px) {
  .enquiry-facts--split { grid-template-columns: 1fr; }
  .enquiry-facts--split li { border-left: 0; padding-left: 0; }
  .enquiry-facts--split li + li { border-top: 1px solid var(--line); }
  .enquiry-form .form-actions .btn { width: 100%; }
}

/* ---------- Floating WhatsApp ---------- */
.wa-float {
  position: fixed;
  right: clamp(1rem, 2.2vw, 1.8rem);
  bottom: clamp(1rem, 2.2vw, 1.8rem);
  z-index: 190;
  display: inline-flex;
  align-items: center;
  background: #1FA855;
  color: #fff;
  border-radius: 999px;
  padding: 0.85rem;
  box-shadow: 0 18px 36px -16px rgba(20, 33, 63, 0.55);
  transition: background 0.3s var(--ease), transform 0.3s var(--ease), bottom 0.35s var(--ease);
}
.wa-float:hover { background: #17853f; transform: translateY(-2px); }
.wa-float:focus-visible { outline: 3px solid rgba(31, 168, 85, 0.45); outline-offset: 3px; }
.wa-float-icon { display: inline-flex; }
.wa-float-label {
  max-width: 0;
  overflow: hidden;
  white-space: nowrap;
  opacity: 0;
  font-family: var(--sans);
  font-size: 0.72rem;
  font-weight: 600;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  transition: max-width 0.4s var(--ease), opacity 0.3s var(--ease), padding 0.4s var(--ease);
}
.wa-float:hover .wa-float-label,
.wa-float:focus-visible .wa-float-label { max-width: 11rem; opacity: 1; padding: 0 0.55rem 0 0.6rem; }
.wa-float.has-cookie { bottom: clamp(8rem, 20vh, 12rem); }
@media (max-width: 560px) {
  .wa-float:hover .wa-float-label { max-width: 0; opacity: 0; padding: 0; }
}
@media (prefers-reduced-motion: reduce) {
  .wa-float, .wa-float-label { transition: none; }
}
"""

css = io.open("css/styles.css", encoding="utf-8").read()
if "FLOATING WHATSAPP" not in css:
    io.open("css/styles.css", "a", encoding="utf-8").write(CSS)
    print("css/styles.css — appended %d lines" % CSS.count("\n"))
else:
    print("css/styles.css — already patched, skipped")

# ---------------------------------------------------------------------------
# 3. js/script.js — form validation + AJAX submit, WhatsApp cookie offset
# ---------------------------------------------------------------------------
JS = """
  /* ============================================================
     ENQUIRY FORM  (contact.html)
     Validates, then posts to FormSubmit's AJAX endpoint so the
     visitor stays on the page. Without JS the form still submits
     natively to the same endpoint.
     ============================================================ */
  (function enquiryForm() {
    const form = document.querySelector("[data-enquiry-form]");
    if (!form) return;

    const status = form.querySelector("[data-form-status]");
    const submit = form.querySelector('button[type="submit"]');
    const AJAX = form.getAttribute("action").replace(
      "https://formsubmit.co/",
      "https://formsubmit.co/ajax/"
    );

    const setStatus = (msg, kind) => {
      if (!status) return;
      status.textContent = msg;
      status.classList.remove("is-error", "is-ok");
      if (kind) status.classList.add(kind);
      status.classList.toggle("is-shown", Boolean(msg));
    };

    const clearError = (el) => {
      el.classList.remove("is-invalid");
      el.removeAttribute("aria-invalid");
      const next = el.parentNode.querySelector(".field-error");
      if (next) next.remove();
    };

    const setError = (el, msg) => {
      el.classList.add("is-invalid");
      el.setAttribute("aria-invalid", "true");
      if (!el.parentNode.querySelector(".field-error")) {
        const p = document.createElement("p");
        p.className = "field-error";
        p.textContent = msg;
        el.parentNode.appendChild(p);
      }
    };

    const EMAIL = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$/;
    const PHONE = /^[+()\\-\\s0-9]{7,}$/;

    const validate = () => {
      const checks = [
        ["name", "Please tell us your full name."],
        ["phone", "Please give a phone number we can reach you on."],
        ["email", "Please give an email address."],
        ["enquiry", "Please tell us briefly what your enquiry is about."],
      ];
      let firstBad = null;
      checks.forEach(([field, msg]) => {
        const el = form.elements[field];
        if (!el) return;
        clearError(el);
        const v = (el.value || "").trim();
        let bad = !v ? msg : "";
        if (!bad && field === "email" && !EMAIL.test(v)) bad = "That email address does not look right.";
        if (!bad && field === "phone" && !PHONE.test(v)) bad = "That phone number does not look right.";
        if (bad) {
          setError(el, bad);
          if (!firstBad) firstBad = el;
        }
      });
      return firstBad;
    };

    form.addEventListener("input", (e) => {
      if (e.target && e.target.classList.contains("is-invalid")) clearError(e.target);
    });

    form.addEventListener("submit", (e) => {
      const firstBad = validate();
      if (firstBad) {
        e.preventDefault();
        setStatus("Please check the highlighted fields and try again.", "is-error");
        firstBad.focus();
        return;
      }
      if (!window.fetch) return; /* let the native POST happen */

      e.preventDefault();
      const data = new FormData(form);
      if (submit) {
        submit.setAttribute("disabled", "disabled");
        submit.dataset.label = submit.textContent;
        submit.textContent = "Sending…";
      }
      setStatus("Sending your enquiry…", null);

      fetch(AJAX, { method: "POST", body: data, headers: { Accept: "application/json" } })
        .then((r) => r.json().catch(() => ({})).then((j) => ({ ok: r.ok, body: j })))
        .then((res) => {
          const success = res.ok && String(res.body.success) !== "false";
          if (!success) throw new Error(res.body.message || "Submission failed");
          form.reset();
          setStatus(
            "Thank you — your enquiry has been sent. You will receive an acknowledgement by email, and a substantive reply from a lawyer within 24 hours.",
            "is-ok"
          );
          track("enquiry_form_submit", { ok: true });
        })
        .catch(() => {
          setStatus(
            "We could not send that just now. Please try again, email scprecords@scp-law.com directly, or message us on WhatsApp.",
            "is-error"
          );
          track("enquiry_form_submit", { ok: false });
        })
        .then(() => {
          if (submit) {
            submit.removeAttribute("disabled");
            submit.textContent = submit.dataset.label || "Send enquiry";
          }
        });
    });
  })();

  /* ============================================================
     FLOATING WHATSAPP — lift clear of the cookie banner
     ============================================================ */
  (function whatsappFloat() {
    const wa = document.querySelector("[data-wa-float]");
    const banner = document.getElementById("cookieBanner");
    if (!wa || !banner) return;
    const sync = () => wa.classList.toggle("has-cookie", banner.classList.contains("is-shown"));
    sync();
    if (window.MutationObserver) {
      new MutationObserver(sync).observe(banner, { attributes: true, attributeFilter: ["class"] });
    }
  })();
"""

js = io.open("js/script.js", encoding="utf-8").read()
if "data-enquiry-form" not in js:
    marker = js.rstrip()
    # append inside the same IIFE the rest of the modules live in, before its close
    idx = marker.rfind("})();")
    assert idx != -1, "could not find the outer IIFE close in script.js"
    js = marker[:idx] + JS + "\n" + marker[idx:] + "\n"
    io.open("js/script.js", "w", encoding="utf-8").write(js)
    print("js/script.js — appended enquiry form + whatsapp modules")
else:
    print("js/script.js — already patched, skipped")

# ---------------------------------------------------------------------------
# 4. Every page — inject the floating WhatsApp button
# ---------------------------------------------------------------------------
count = 0
for root, dirs, files in os.walk("."):
    dirs[:] = [d for d in dirs if not d.startswith((".", "_"))]
    for f in sorted(files):
        if not f.endswith(".html"):
            continue
        p = os.path.join(root, f)
        t = io.open(p, encoding="utf-8").read()
        if "data-wa-float" in t or "</body>" not in t:
            continue
        t = t.replace("</body>", WA_HTML + "\n</body>", 1)
        io.open(p, "w", encoding="utf-8").write(t)
        count += 1
print("whatsapp button injected into %d pages" % count)
