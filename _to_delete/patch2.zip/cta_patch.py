# -*- coding: utf-8 -*-
"""Route practice + service enquiry CTAs to contact.html, and replace the
dead 'Request this service' forms with a CTA that goes there too."""
import io, os, re, sys, glob

os.chdir(sys.argv[1])
MS = "https://forms.cloud.microsoft/Pages/ResponsePage.aspx?id=emEZHjkf7EqeDd6JuRMfnZ5g24hVddtNlcfkCrapooRUQlA4Q0dPUVJOTUJZR1VQWUc3R0dMNUlPVC4u"
CONTACT = "../contact.html#enquire"
report = []

# ---------------------------------------------------------------------------
# 1. SERVICE PAGES — replace the whole #request form section
# ---------------------------------------------------------------------------
SECTION = re.compile(
    r'  <section class="section section--paper" id="request">.*?\n  </section>\n', re.S)

for path in sorted(glob.glob("services/*.html")):
    t = io.open(path, encoding="utf-8").read()
    m = SECTION.search(t)
    if not m:
        report.append((path, "no #request section — skipped"))
        continue
    block = m.group(0)

    name = re.search(r'<h2 class="section-title">Request (.*?)\.</h2>', block)
    team = re.search(r'This request routes to the (.*?)\.', block)
    name = name.group(1) if name else "this service"
    team = team.group(1) if team else "responsible team"
    slug = os.path.basename(path)[:-5]

    new = (
        '  <section class="section section--paper" id="request">\n'
        '    <div class="container split">\n'
        '      <div class="reveal">\n'
        '        <p class="eyebrow"><span class="rule"></span>Request</p>\n'
        '        <h2 class="section-title">Request %s.</h2>\n'
        '        <p class="section-note mt-lg">This request routes to the %s. We confirm scope and fee in writing before any work begins.</p>\n'
        '      </div>\n'
        '      <aside class="press-panel reveal">\n'
        '        <p class="card-cat">How to request it</p>\n'
        '        <h3 class="press-panel-title">Send us the details.</h3>\n'
        '        <ul class="press-list">\n'
        '          <li>Tell us the scope you have in mind, and any deadline</li>\n'
        '          <li>We confirm scope and fee in writing before any work begins</li>\n'
        '          <li>Acknowledgement immediately, a lawyer&#8217;s reply within 24 hours</li>\n'
        '        </ul>\n'
        '        <a class="btn btn--primary" href="%s" data-track="cta:request-service:%s">Request this service</a>\n'
        '        <p class="press-panel-note">Mention <em>%s</em> in your enquiry so it reaches the %s directly.</p>\n'
        '      </aside>\n'
        '    </div>\n'
        '  </section>\n' % (name, team, CONTACT, slug, name, team)
    )
    t = t[:m.start()] + new + t[m.end():]

    # sidebar "Request this service" button
    before = t.count(MS)
    t = t.replace('href="%s" class="btn btn--primary"' % MS,
                  'href="%s" class="btn btn--primary"' % CONTACT)
    t = re.sub(r'(<a href="\.\./contact\.html#enquire" class="btn btn--primary"[^>]*?)\s*target="_blank" rel="noopener"',
               r'\1', t)
    io.open(path, "w", encoding="utf-8").write(t)
    report.append((path, "form section replaced; %d MS link(s) retargeted" % (before - t.count(MS))))

# ---------------------------------------------------------------------------
# 2. PRACTICE PAGES — retarget both CTAs
# ---------------------------------------------------------------------------
for path in sorted(glob.glob("practice/*.html")):
    t = io.open(path, encoding="utf-8").read()
    before = t.count(MS)

    # "Enquire about this practice" (sidebar)
    t = t.replace('href="%s" class="plan-enquire"' % MS,
                  'href="%s" class="plan-enquire"' % CONTACT)
    # "Submit an enquiry" (enquiry band)
    t = t.replace('href="%s" data-enquiry-link' % MS,
                  'href="%s" data-enquiry-link' % CONTACT)
    # strip new-tab attributes from the two links we just repointed
    t = re.sub(r'(<a [^>]*href="\.\./contact\.html#enquire"[^>]*?)\s*target="_blank" rel="noopener"',
               r'\1', t)
    # copy that referenced the Microsoft form's topic dropdown
    t = t.replace("Opens our secure enquiry form in a new tab",
                  "Takes you to the enquiry form on our contact page")
    t = re.sub(r'Choose <em>(.*?)</em> as the topic on the form and a lawyer from the team picks it up\.',
               r'Mention <em>\1</em> in your enquiry and a lawyer from the team picks it up.', t)

    io.open(path, "w", encoding="utf-8").write(t)
    report.append((path, "%d MS link(s) retargeted" % (before - t.count(MS))))

for p, msg in report:
    print("  %-46s %s" % (p, msg))

# ---------------------------------------------------------------------------
# 3. Checks
# ---------------------------------------------------------------------------
print("\n--- verification ---")
bad = []
for path in sorted(glob.glob("services/*.html") + glob.glob("practice/*.html")):
    t = io.open(path, encoding="utf-8").read()
    if 'data-form="enquiry"' in t and path.startswith("services/"):
        bad.append((path, "dead form still present"))
    for tag in ("section", "div", "aside", "form", "main"):
        o = len(re.findall(r"<%s[ >]" % tag, t)); c = t.count("</%s>" % tag)
        if o != c:
            bad.append((path, "%s %d/%d" % (tag, o, c)))
    for h in re.findall(r'href="(\.\./[^"#]+)(?:#[^"]*)?"', t):
        tgt = os.path.normpath(os.path.join(os.path.dirname(path), h))
        if not os.path.exists(tgt):
            bad.append((path, "broken link " + h))
print("problems:", bad if bad else "none")
print("remaining Microsoft-form links — practice:",
      sum(io.open(p, encoding='utf-8').read().count(MS) for p in glob.glob("practice/*.html")),
      "| services:",
      sum(io.open(p, encoding='utf-8').read().count(MS) for p in glob.glob("services/*.html")))
